//
// Shani Herskowitz: 321659387
// Liora Zaidner: 323742775
//

#include "Menu.h"
int main() {
  Menu *menu = new Menu();
  menu->showMenu();
  delete menu;

  return 0;
}