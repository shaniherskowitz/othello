#ifndef OTHELLO_TILE_H
#define OTHELLO_TILE_H

/**
 * Defining an enum for the Tile symbols.
 */
enum Tile { X, O, EMPTY };

#endif //OTHELLO_TILE_H
